# Site homenageando Street Fighter 3
***
Neste site abordei conteúdos simples do jogo, como:
* Personagens;
* Cenarários;
* História do _game_ e dos _personagens_;
* Desenvolvedora;
* Distribuidoras.
***
### OBS: meu primeiro site com _HTML_ e _CSS_.

