<?php

session_start();


if (!isset($_SESSION['id_usuario']) || $_SESSION['id_usuario'] === null) {
    header("Location: ../login.php"); 
    exit();
}


include 'conexaoKel.php'; 


$origem_dashboard = 'manutencao_dashboard.php'; 


function redirectToDashboard($status, $message, $dashboard_origem) {

    $message = htmlspecialchars($message);

    $css_class = ($status === 'sucesso') ? 'sucesso' : 'erro';
    $icon = ($status === 'sucesso') ? '✅ Sucesso: ' : '❌ Erro: ';
    $url_retorno = "../dashboards/" . htmlspecialchars($dashboard_origem);
    
    echo "<!DOCTYPE html><html lang='pt-br'><head><meta charset='UTF-8'><title>Status da Operação</title>";
   
    echo "<meta http-equiv=\"refresh\" content=\"5;url=" . $url_retorno . "\">"; 
    echo "<style>";
    echo "body { font-family: Arial, sans-serif; padding: 50px; background-color: #f4f4f9; text-align: center; }";
    echo ".container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }";
    echo ".msg { padding: 20px; margin: 20px 0; border-radius: 5px; font-size: 1.1rem; line-height: 1.5; }";
    echo ".sucesso { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }";
    echo ".erro { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }";
    echo ".btn-voltar { display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; transition: background-color 0.3s; }";
    echo ".btn-voltar:hover { background-color: #0056b3; }";
    echo "</style></head><body>";
    
    echo "<div class='container'>";
    echo "<h1>" . $icon . "Operação Realizada!</h1>";
    echo "<div class='msg " . $css_class . "'>";
    echo $message;
    echo "</div>";
    echo "<p>Você será redirecionado automaticamente em 5 segundos...</p>";
    echo "<p>";
    echo "<a href='" . $url_retorno . "' class='btn-voltar'>Voltar Imediatamente para o Dashboard</a>";
    echo "</p>";
    echo "</div></body></html>";
    exit(); 
}


$id_ocorrencia = $_POST['id_ocorrencia'] ?? null;
$novo_status = $_POST['novo_status'] ?? null;

if (!$id_ocorrencia || !$novo_status) {
    redirectToDashboard('erro', "Dados insuficientes para tratar o chamado. ID ou Status faltando.", $origem_dashboard);
}


$data_hora_agora = date('Y-m-d H:i:s'); 

try {

    $mensagem = "Status do Chamado #{$id_ocorrencia} atualizado com sucesso.";
    $data_sql_value = NULL; 

    if ($novo_status === 'Resolvido') {
      
        $data_sql_value = $data_hora_agora;
        $mensagem = "Ocorrência #{$id_ocorrencia} marcada como **Resolvida**. O chamado será exibido como concluído.";
    } elseif ($novo_status === 'Em Andamento') {
      
        $mensagem = "Ocorrência #{$id_ocorrencia} marcada como **Em Andamento**. O chamado está sendo tratado.";
    } elseif ($novo_status === 'Aberto') {
       
        $mensagem = "Ocorrência #{$id_ocorrencia} foi **Reaberta**. Retornou para o início da fila de atendimento.";
    } else {
        throw new Exception("Status de destino inválido.");
    }

    
    $sql = "UPDATE Ocorrencias SET status_ocorrencia = ?, data_conclusao = ? WHERE id_ocorrencia = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$novo_status, $data_sql_value, $id_ocorrencia]);


    redirectToDashboard('sucesso', $mensagem, $origem_dashboard);

} catch (PDOException $e) {
    redirectToDashboard('erro', "Erro de Banco de Dados: Não foi possível atualizar o chamado.", $origem_dashboard);
} catch (Exception $e) {
    redirectToDashboard('erro', $e->getMessage(), $origem_dashboard);
}
?>