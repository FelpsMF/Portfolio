<?php
session_start();

require_once 'conexaoKel.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nome_usuario_digitado = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_SPECIAL_CHARS);
    $password_digitada = $_POST['password']; 

   $sql = "SELECT id_usuario, senha, funcao_id 
        FROM Usuarios 
        WHERE BINARY nome_usuario = :nome_usuario";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':nome_usuario', $nome_usuario_digitado);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password_digitada, $user['senha'])) {
            
            $_SESSION['loggedin'] = true;
            $_SESSION['id_usuario'] = $user['id_usuario']; 
            $_SESSION['nome_usuario'] = $nome_usuario_digitado; 
            $_SESSION['role_id'] = $user['funcao_id']; 
            
            switch ($_SESSION['role_id']) { 
                case 4: 
                    header("Location: ../dashboards/professor_dashboard.php");
                    break;
                case 3: 
                    header("Location: ../dashboards/portaria_dashboard.php");
                    break;
                case 2: 
                    header("Location: ../dashboards/gestao_dashboard.php");
                    break;
                case 1: 
                    header("Location: ../dashboards/manutencao_dashboard.php");
                    break;
                default:
                    header("Location: ../login.php?error=1"); 
                    break;
            }
            exit;

        } else {
            header("Location: ../login.php?error=1"); 
            exit;
        }
    } catch (PDOException $e) {
        error_log("Erro na consulta de autenticação: " . $e->getMessage()); 
        header("Location: ../login.php?error=1");
        exit;
    }

} else {
    header("Location: ../login.php"); 
    exit;
}
?>