<?php

session_start();

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_usuario'] === null) {
    header("Location: ../login.php"); 
    exit();
}

include 'conexaoKel.php';


function sanitizeInput($data) {
    return htmlspecialchars(trim($data));
}


function redirectToDashboard($status, $message, $dashboard_origem = 'gestao_dashboard.php') {
    $redirect_url = "../dashboards/" . $dashboard_origem;
    $status_class = ($status === 'sucesso') ? 'sucesso' : 'erro';
    $title = ($status === 'sucesso') ? 'Sucesso' : 'Erro';
    $icon = ($status === 'sucesso') ? '✅' : '❌';
    
    echo "<!DOCTYPE html><html lang='pt-br'><head><meta charset='UTF-8'><title>$title</title>";
    echo "<meta http-equiv='refresh' content='3;url=" . htmlspecialchars($redirect_url) . "'>"; 
    
 
    echo "<style>body { font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f9; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }";
    echo ".msg-container { width: 100%; max-width: 500px; padding: 20px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); background-color: white; border-radius: 8px; text-align: center; }";
    echo ".msg { padding: 15px; margin: 10px 0; border-radius: 5px; font-size: 1.1rem; }";
    echo ".sucesso { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }";
    echo ".erro { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }";
    echo "a { color: #007bff; text-decoration: none; font-weight: bold; } a:hover { text-decoration: underline; }</style></head><body>";
    
    echo "<div class='msg-container'>";
    echo "<h3>$icon $title na Operação</h3>";
    echo "<div class='msg " . $status_class . "'>";
    echo htmlspecialchars($message);
    echo "</div>";
    echo "<p>Você será redirecionado automaticamente em 3 segundos. Se não for, clique no link abaixo.</p>";
    echo "<p><a href='" . htmlspecialchars($redirect_url) . "'>Voltar para o Dashboard</a></p>";
    echo "</div></body></html>";
    exit();
}

function excluir($pdo, $tabela, $campoId, $valor) {
    if (!$valor) return false;
    $sql = "DELETE FROM $tabela WHERE $campoId = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$valor]);
    return $stmt->rowCount() > 0;
}

$origem = sanitizeInput($_GET['origem_dashboard'] ?? 'gestao_dashboard.php'); 

$pdo->beginTransaction();

try {
    $excluido_com_sucesso = false;
    $message = "Nenhuma exclusão solicitada ou ID não fornecido.";

    if (isset($_GET['id_emprestimo'])) {
        $excluido_com_sucesso = excluir($pdo, 'Emprestimo', 'id_emprestimo', $_GET['id_emprestimo']);
        if ($excluido_com_sucesso) $message = "Empréstimo excluído com sucesso!";
    }
    if (isset($_GET['id_ocorrencia'])) {
        $excluido_com_sucesso = excluir($pdo, 'Ocorrencias', 'id_ocorrencia', $_GET['id_ocorrencia']);
        if ($excluido_com_sucesso) $message = "Ocorrência excluída com sucesso!";
    }

    if (isset($_GET['id_equip'])) {
        $excluido_com_sucesso = excluir($pdo, 'Equipamentos', 'id_equip', $_GET['id_equip']);
        if ($excluido_com_sucesso) $message = "Equipamento excluído com sucesso!";
    }
    if (isset($_GET['id_usuario'])) {
        $excluido_com_sucesso = excluir($pdo, 'Usuarios', 'id_usuario', $_GET['id_usuario']);
        if ($excluido_com_sucesso) $message = "Usuário excluído com sucesso!";
    }
    if (isset($_GET['id_sala'])) { 
        $excluido_com_sucesso = excluir($pdo, 'Sala', 'id_sala', $_GET['id_sala']);
        if ($excluido_com_sucesso) $message = "Sala excluída com sucesso!";
    }
    
    $pdo->commit();
    
    $status = $excluido_com_sucesso ? 'sucesso' : 'erro';
    if (!$excluido_com_sucesso) $message = "Nenhuma exclusão foi efetuada, verifique se o item existe ou se houve erro no ID.";

    redirectToDashboard($status, $message, $origem);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, 'Foreign key constraint') !== false) {
        $message = "Não foi possível excluir. Existem registros (empréstimos, chamados, etc.) vinculados a este item. Exclua os registros filhos primeiro.";
    } else {
        $message = "Erro ao excluir: " . $errorMessage;
    }
    
    redirectToDashboard('erro', $message, $origem);

} catch (Exception $e) {
    $pdo->rollBack();
    $message = "Erro inesperado: " . $e->getMessage();
    redirectToDashboard('erro', $message, $origem);
}
?>