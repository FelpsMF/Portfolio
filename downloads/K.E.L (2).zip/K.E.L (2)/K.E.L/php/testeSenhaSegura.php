<?php
$senha_pura = 'marcelo1234';
$hash = password_hash($senha_pura, PASSWORD_DEFAULT);
echo "Senha Pura: " . $senha_pura . "<br>";
echo "HASH Gerado: " . $hash . "<br>"; 
?>

<?php
$senha_pura = 'andre1234';
$hash = password_hash($senha_pura, PASSWORD_DEFAULT);
echo "Senha Pura: " . $senha_pura . "<br>";
echo "HASH Gerado: " . $hash . "<br>"; 
?>

<?php
$senha_pura = 'vivi1234';
$hash = password_hash($senha_pura, PASSWORD_DEFAULT);
echo "Senha Pura: " . $senha_pura . "<br>";
echo "HASH Gerado: " . $hash . "<br>"; 
?>

<?php
$senha_pura = 'gabriel1234';
$hash = password_hash($senha_pura, PASSWORD_DEFAULT);
echo "Senha Pura: " . $senha_pura . "<br>";
echo "HASH Gerado: " . $hash . "<br>"; 
?>
