<?php
$dbNome = "bd_Kel";

$conexao = mysqli_connect('localhost', 'root', '') or die("Erro de conexão");
mysqli_query($conexao, "CREATE DATABASE IF NOT EXISTS $dbNome");
mysqli_select_db($conexao, $dbNome);


$tbSala   = "Sala";
$tbFunc   = "Funcao";
$tbUser   = "Usuarios";
$tbEquipa = "Equipamentos";
$tbEmpre  = "Emprestimo";
$tbOcorren = "Ocorrencias";



$dropTables = [
    $tbOcorren,
    $tbEmpre,
    $tbEquipa,
    $tbUser,
    $tbSala,
    $tbFunc
];

echo "<h3>🧹 Iniciando Limpeza de Tabelas Existentes...</h3>";
foreach ($dropTables as $table) {
  
    $dropSQL = "DROP TABLE IF EXISTS $table";
    if (mysqli_query($conexao, $dropSQL)) {
        echo "✅ Tabela $table removida (se existisse).<br>";
    } else {
        echo "❌ Erro ao remover tabela $table: " . mysqli_error($conexao) . "<br>";
    }
}
echo "<hr>";


$criaSala = "CREATE TABLE IF NOT EXISTS $tbSala (
    id_sala INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_sala VARCHAR(45) UNIQUE, 
    identificacao_chave VARCHAR(40) UNIQUE, 
    desc_sala VARCHAR(200),
    status_sala VARCHAR(45)
)";


$criaFunc = "CREATE TABLE IF NOT EXISTS $tbFunc (
    id_funcao INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_funcao VARCHAR(45)
)";

 
$criaUser = "CREATE TABLE IF NOT EXISTS $tbUser (
    id_usuario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    funcao_id INT NOT NULL,
    nome_usuario VARCHAR(100) UNIQUE,
    email VARCHAR(150) UNIQUE,
    senha VARCHAR(255),
    FOREIGN KEY (funcao_id) REFERENCES $tbFunc(id_funcao)
)";


$criaEquipa = "CREATE TABLE IF NOT EXISTS $tbEquipa (
    id_equip INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_equipa VARCHAR(45),
    identificacao_equipa VARCHAR(45),
    desc_equip VARCHAR(200),
    salas_id_sala INT,
    FOREIGN KEY (salas_id_sala) REFERENCES $tbSala(id_sala)
)";


$criaEmpre = "CREATE TABLE IF NOT EXISTS $tbEmpre (
    id_emprestimo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    salas_id_sala INT,
    usuario_id_usuario INT,
    data_hora_retirada VARCHAR(45),
    data_hora_devolucao VARCHAR(45),
    FOREIGN KEY (salas_id_sala) REFERENCES $tbSala(id_sala),
    FOREIGN KEY (usuario_id_usuario) REFERENCES $tbUser(id_usuario)
)";

$criaOcorren = "CREATE TABLE IF NOT EXISTS $tbOcorren (
    id_ocorrencia INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sala_id INT,
    equipamentos_id_equip INT,
    usuarios_id_usuario INT,
    funcao_id_funcao INT,
    desc_ocorrencia VARCHAR(200),
    status_ocorrencia VARCHAR(45),
    data_abertura VARCHAR(45),
    data_conclusao VARCHAR(45),
    FOREIGN KEY (sala_id) REFERENCES $tbSala(id_sala),
    FOREIGN KEY (equipamentos_id_equip) REFERENCES $tbEquipa(id_equip),
    FOREIGN KEY (funcao_id_funcao) REFERENCES $tbFunc(id_funcao),
    FOREIGN KEY (usuarios_id_usuario) REFERENCES $tbUser(id_usuario)
)";


$hash_marcelo = password_hash('marcelo1234', PASSWORD_DEFAULT);
$hash_andre = password_hash('andre1234', PASSWORD_DEFAULT);
$hash_vivi = password_hash('vivi1234', PASSWORD_DEFAULT);
$hash_gabriel = password_hash('biel1234', PASSWORD_DEFAULT);

$inserirFuncao = "INSERT INTO Funcao (nome_funcao) VALUES
('Manutenção'),
('Gestão'),
('Porteiro'),
('Professor');";


$inserirUser = "INSERT INTO Usuarios (funcao_id, nome_usuario, email, senha)
VALUES
(4, 'Marcelo' , 'marcelo1234@gmail.com', '$hash_marcelo'), 
(3, 'Andre', 'andre1234@gmail.com', '$hash_andre'),  
(2, 'Vivi', 'vivi1234@gmail.com', '$hash_vivi'),     
(1, 'Gabriel', 'biel1234@gmail.com', '$hash_gabriel');"; 



echo "<h3>🔨 Criando Tabelas...</h3>";

$tabelas = [
    "Função"       => $criaFunc,
    "Sala"         => $criaSala, 
    "Usuários"     => $criaUser,
    "Equipamentos" => $criaEquipa,
    "Empréstimos"  => $criaEmpre,
    "Ocorrências"  => $criaOcorren
];


foreach ($tabelas as $nome => $sql) {
    $resultado = mysqli_query($conexao, $sql);
    if (!$resultado) {
     
        die("❌ Erro ao criar tabela $nome: " . mysqli_error($conexao));
    } else {
        echo "✅ Tabela **$nome** criada com sucesso.<br>";
    }
}
echo "<hr>";


echo "<h3>📝 Inserindo Dados de Teste...</h3>";


$resultado_insert_funcao = mysqli_query($conexao, $inserirFuncao);
if (!$resultado_insert_funcao) {
    echo "❌ Erro ao inserir Funções: " . mysqli_error($conexao) . "<br>";
} else {
    $linhas_inseridas = mysqli_affected_rows($conexao); 
    echo "✅ **$linhas_inseridas** dados de teste inseridos na tabela **Funcao** com sucesso.<br>";
}

$resultado_insert_user = mysqli_query($conexao, $inserirUser);
if (!$resultado_insert_user) {
    echo "❌ Erro ao inserir Usuários: " . mysqli_error($conexao) . "<br>";
} else {
    $linhas_inseridas = mysqli_affected_rows($conexao); 
    echo "✅ **$linhas_inseridas** dados de teste inseridos na tabela **Usuarios** com sucesso.<br>";
}

echo "<hr><h3>🎉 Setup do banco de dados `bd_Kel` concluído!</h3>";

mysqli_close($conexao);

?>