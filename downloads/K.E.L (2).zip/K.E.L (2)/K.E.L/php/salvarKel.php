<?php

session_start();


if (!isset($_SESSION['id_usuario']) || $_SESSION['id_usuario'] === null) {
    header("Location: ../login.php"); 
    exit();
}

include 'conexaoKel.php'; 

function sanitizeInput($data) {
    if (is_array($data)) return array_map('sanitizeInput', $data);
    if (is_null($data) || $data === '') return null;
    return htmlspecialchars(trim($data)); 
}

function redirectToDashboard($status, $message, $origem_dashboard = 'gestao_dashboard.php') {
    $redirect_url = "../dashboards/" . $origem_dashboard;
    $status_class = ($status === 'sucesso') ? 'sucesso' : 'erro';
    $title = ($status === 'sucesso') ? 'Sucesso' : 'Erro';
    $icon = ($status === 'sucesso') ? '✅' : '❌';
    
    echo "<!DOCTYPE html><html lang='pt-br'><head><meta charset='UTF-8'><title>$title</title>";
    echo "<meta http-equiv='refresh' content='3;url=" . htmlspecialchars($redirect_url) . "'>";
    
    echo "<style>body { font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f9; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }";
    echo ".msg-container { width: 100%; max-width: 500px; padding: 20px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); background-color: white; border-radius: 8px; text-align: center; }";
    echo ".msg { padding: 15px; margin: 10px 0; border-radius: 5px; font-size: 1.1rem; }";
    echo ".sucesso { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }";
    echo ".erro { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }";
    echo "a { color: #007bff; text-decoration: none; font-weight: bold; } a:hover { text-decoration: underline; }</style></head><body>";
    
    echo "<div class='msg-container'>";
    echo "<h3>$icon $title na Operação</h3>";
    echo "<div class='msg " . $status_class . "'>";
    echo htmlspecialchars($message);
    echo "</div>";
    echo "<p>Você será redirecionado automaticamente em 3 segundos. Se não for, clique no link abaixo.</p>";
    echo "<p><a href='" . htmlspecialchars($redirect_url) . "'>Voltar para o Dashboard</a></p>";
    echo "</div></body></html>";
    exit(); 
}

$contexto = $_POST['contexto'] ?? ''; 
$operacao = $_POST['operacao'] ?? ''; 
$origem_dashboard = $_POST['origem_dashboard'] ?? 'gestao_dashboard.php';

try { 
    $pdo->beginTransaction(); 

    $message = "Operação concluída com sucesso."; 
    

    if ($contexto === 'gestao_usuario') {
        $id_usuario = sanitizeInput($_POST['id_usuario'] ?? null);
        $nome_usuario = sanitizeInput($_POST['nome_usuario']);
        $email = sanitizeInput($_POST['email']);
        $senha = $_POST['senha'] ?? '';
        $funcao_id = sanitizeInput($_POST['funcao_id']);

        if ($operacao === 'insert') {
            if (empty($senha)) throw new Exception("A senha é obrigatória para novos cadastros.");
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $sql = "INSERT INTO Usuarios (nome_usuario, email, senha, funcao_id) VALUES (?, ?, ?, ?)";
            $pdo->prepare($sql)->execute([$nome_usuario, $email, $senha_hash, $funcao_id]);
            $message = "Usuário '$nome_usuario' cadastrado com sucesso!";
        } elseif ($operacao === 'update') {
            $sql = "UPDATE Usuarios SET nome_usuario = ?, email = ?, funcao_id = ?";
            $params = [$nome_usuario, $email, $funcao_id];
            
            if (!empty($senha)) {
                $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
                $sql .= ", senha = ?";
                $params[] = $senha_hash;
            }
            
            $sql .= " WHERE id_usuario = ?";
            $params[] = $id_usuario;
            
            $pdo->prepare($sql)->execute($params);
            $message = "Usuário ID $id_usuario ('$nome_usuario') atualizado com sucesso!";
        } else {
             throw new Exception("Operação de gestão de usuário inválida.");
        }
        $origem_dashboard = 'gestao_dashboard.php';


    } elseif ($contexto === 'portaria_emprestimo') {
        $usuario_id_usuario = sanitizeInput($_POST['usuario_id_usuario']);
        $salas_id_sala = sanitizeInput($_POST['salas_id_sala']);
        $data_hora_retirada = date('Y-m-d H:i:s'); 
        
        $sql = "INSERT INTO Emprestimo (usuario_id_usuario, salas_id_sala, data_hora_retirada) VALUES (?, ?, ?)";
        $pdo->prepare($sql)->execute([$usuario_id_usuario, $salas_id_sala, $data_hora_retirada]);
        
        $sql_sala = "UPDATE Sala SET status_sala = 'Emprestado' WHERE id_sala = ?";
        $pdo->prepare($sql_sala)->execute([$salas_id_sala]);
        
        $message = "Empréstimo de chave registrado com sucesso!";
        $origem_dashboard = 'portaria_dashboard.php';


    } elseif ($contexto === 'portaria_devolucao') {
        $id_emprestimo = sanitizeInput($_POST['id_emprestimo']);
        $data_hora_devolucao = date('Y-m-d H:i:s');

        $sql_select = "SELECT salas_id_sala FROM Emprestimo WHERE id_emprestimo = ?";
        $stmt_select = $pdo->prepare($sql_select);
        $stmt_select->execute([$id_emprestimo]);
        $emprestimo_info = $stmt_select->fetch(PDO::FETCH_ASSOC);

        if (!$emprestimo_info) throw new Exception("Empréstimo não encontrado.");
        $salas_id_sala = $emprestimo_info['salas_id_sala'];

        $sql = "UPDATE Emprestimo SET data_hora_devolucao = ? WHERE id_emprestimo = ?";
        $pdo->prepare($sql)->execute([$data_hora_devolucao, $id_emprestimo]);
        
        $sql_sala = "UPDATE Sala SET status_sala = 'Disponível' WHERE id_sala = ?";
        $pdo->prepare($sql_sala)->execute([$salas_id_sala]);
        
        $message = "Devolução de chave registrada com sucesso!";
        $origem_dashboard = 'portaria_dashboard.php';

   

    } elseif ($contexto === 'portaria_cadastro_sala') {
        $id_sala = sanitizeInput($_POST['id_sala'] ?? null);
        $nome_sala = sanitizeInput($_POST['nome_sala']);
        $identificacao_chave = sanitizeInput($_POST['identificacao_chave']);
        $desc_sala = sanitizeInput($_POST['desc_sala']);
        $status_sala = sanitizeInput($_POST['status_sala'] ?? 'Disponível');

        if ($operacao === 'insert') {
            $sql = "INSERT INTO Sala (nome_sala, identificacao_chave, desc_sala, status_sala) VALUES (?, ?, ?, 'Disponível')";
            $pdo->prepare($sql)->execute([$nome_sala, $identificacao_chave, $desc_sala]);
            $message = "Chave/Sala '$nome_sala' cadastrada com sucesso!";
        } elseif ($operacao === 'update') {
            $sql = "UPDATE Sala SET nome_sala = ?, identificacao_chave = ?, desc_sala = ?, status_sala = ? WHERE id_sala = ?";
            $pdo->prepare($sql)->execute([$nome_sala, $identificacao_chave, $desc_sala, $status_sala, $id_sala]);
            $message = "Chave/Sala ID $id_sala ('$nome_sala') atualizada com sucesso!";
        } else {
             throw new Exception("Operação de cadastro de sala inválida.");
        }
        $origem_dashboard = 'portaria_dashboard.php';

  

    } elseif ($contexto === 'professor_ocorrencia') {
        $usuarios_id_usuario = sanitizeInput($_POST['usuarios_id_usuario']);
        $sala_id = sanitizeInput($_POST['sala_id']);
        $equipamentos_id_equip = sanitizeInput($_POST['equipamentos_id_equip'] ?? null);
        $desc_ocorrencia = sanitizeInput($_POST['desc_ocorrencia']);
        $data_abertura = date('Y-m-d H:i:s');
        $status_ocorrencia = 'Aberto';
        
        $sql = "INSERT INTO Ocorrencias (usuarios_id_usuario, sala_id, equipamentos_id_equip, desc_ocorrencia, data_abertura, status_ocorrencia) VALUES (?, ?, ?, ?, ?, ?)";
        $pdo->prepare($sql)->execute([$usuarios_id_usuario, $sala_id, $equipamentos_id_equip, $desc_ocorrencia, $data_abertura, $status_ocorrencia]);
        $message = "Chamado (Ocorrência) registrado com sucesso! Acompanhe o status no painel.";
        $origem_dashboard = 'professor_dashboard.php';

    

    } elseif ($contexto === 'tratar_chamado') {
        $id_ocorrencia = $_POST['id_ocorrencia'] ?? null;
        $novo_status = $_POST['novo_status'] ?? null;
        
        if (!$id_ocorrencia || !$novo_status) {
            throw new Exception("Dados insuficientes para tratar o chamado. ID ou Status faltando.");
        }
        
        $id_ocorrencia = (int)$id_ocorrencia;
        $params = [
            ':novo_status' => $novo_status,
            ':id_ocorrencia' => $id_ocorrencia
        ];

        $sql = "UPDATE Ocorrencias SET 
                    status_ocorrencia = :novo_status, 
                    data_conclusao = NULL 
                WHERE id_ocorrencia = :id_ocorrencia";
        
        if (in_array($novo_status, ['Resolvido', 'Cancelado'])) {
            $sql = "UPDATE Ocorrencias SET 
                        status_ocorrencia = :novo_status, 
                        data_conclusao = NOW() 
                    WHERE id_ocorrencia = :id_ocorrencia";
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        $message = "Status do Chamado #$id_ocorrencia atualizado para '$novo_status' com sucesso!";
        $origem_dashboard = 'manutencao_dashboard.php';

    

    } elseif ($contexto === 'manutencao_equipamento') {
        $id_equip = (int)($_POST['id_equip'] ?? 0);
        $nome_equipa = sanitizeInput($_POST['nome_equipa']);
        $identificacao_equipa = sanitizeInput($_POST['identificacao_equipa']);
        $desc_equip = sanitizeInput($_POST['desc_equip']);
        $salas_id_sala = (int)($_POST['salas_id_sala'] ?? 0);

        if (empty($nome_equipa) || empty($identificacao_equipa) || $salas_id_sala === 0) {
            throw new Exception("Nome, Identificação e Sala são obrigatórios para o equipamento.");
        }

        if ($operacao === 'insert') {
            $sql = "INSERT INTO Equipamentos (nome_equipa, identificacao_equipa, desc_equip, salas_id_sala) 
                    VALUES (?, ?, ?, ?)";
            $pdo->prepare($sql)->execute([$nome_equipa, $identificacao_equipa, $desc_equip, $salas_id_sala]);
            $message = "Novo equipamento '$nome_equipa' cadastrado com sucesso!";
        } elseif ($operacao === 'update' && $id_equip > 0) {
            $sql = "UPDATE Equipamentos SET nome_equipa = ?, identificacao_equipa = ?, desc_equip = ?, salas_id_sala = ? WHERE id_equip = ?";
            $pdo->prepare($sql)->execute([$nome_equipa, $identificacao_equipa, $desc_equip, $salas_id_sala, $id_equip]);
            $message = "Equipamento ID $id_equip (Nome: '$nome_equipa') atualizado com sucesso!";
        } else {
             throw new Exception("Operação de cadastro de equipamento inválida.");
        }
        $origem_dashboard = 'manutencao_dashboard.php';

    

    } else { 
        throw new Exception("Contexto ou operação não reconhecidos."); 
    } 

    $pdo->commit(); 
   
    redirectToDashboard('sucesso', $message, $origem_dashboard); 
    
} catch (Exception $e) { 
    if ($pdo->inTransaction()) { 
        $pdo->rollBack(); 
    } 
    $errorMessage = $e->getMessage(); 
    if (strpos($errorMessage, 'Integrity constraint violation: 1062 Duplicate entry') !== false) { 
        $errorMessage = "Já existe um registro com este valor. Verifique se o Nome, Email ou Identificação já foram cadastrados."; 
    } 
    
    redirectToDashboard('erro', "Erro de processamento: " . $errorMessage, $origem_dashboard); 
} 
?>