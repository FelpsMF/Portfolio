<?php
    $servidor = "localhost";
    $usuario = "root";
    $senha = "";
    $banco = "bd_Kel";

    try {
        $pdo = new PDO("mysql:host=$servidor;dbname=$banco", $usuario, $senha);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e) {
        die("<h3>Erro de conexão com o banco de dados Kel</h3>" . $e->getMessage());
    }
?>