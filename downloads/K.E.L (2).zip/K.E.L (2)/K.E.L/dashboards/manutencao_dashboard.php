<?php

session_start();


$mensagem_sucesso = $_SESSION['sucesso'] ?? '';
$mensagem_erro = $_SESSION['erro'] ?? '';
unset($_SESSION['sucesso']);
unset($_SESSION['erro']);

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_usuario'] === null) {
   
    header("Location: ../login.php"); 
    exit();
}

include '../php/conexaoKel.php'; 


function buscarTodos($pdo, $tabela) {
    $sql = "SELECT * FROM $tabela";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


function limitar_texto($texto, $limite) {
    if (!$texto) return 'N/A';
   
    $texto = (string) $texto; 
    if (strlen($texto) > $limite) {
       
        return mb_substr($texto, 0, $limite, 'UTF-8') . '...';
    }
    return $texto;
}

$equipamentos = "Equipamentos";
$ocorrencias = "Ocorrencias";
$usuarios = "Usuarios";
$sala = "Sala";
$funcao = "Funcao";
$nome_usuario_logado = $_SESSION['nome_usuario'] ?? 'Usuário';


try {
   
    $sql_salas = "SELECT id_sala, nome_sala FROM $sala ORDER BY nome_sala";
    $stmt_salas = $pdo->query($sql_salas);
    $salas_list = $stmt_salas->fetchAll(PDO::FETCH_ASSOC);
    
    
    $equipamentos_list = buscarTodos($pdo, $equipamentos);

} catch (PDOException $e) {
   
    echo "Erro ao carregar dados: " . $e->getMessage();
    $salas_list = [];
    $equipamentos_list = [];
}


$equipToEdit = null;
$operacao_form = 'insert';
$form_title = 'Cadastrar Novo Equipamento';

$id_equip_edit = $_GET['id_equip'] ?? null;

if ($id_equip_edit) {
  
    $sql_edit = "SELECT * FROM Equipamentos WHERE id_equip = ?";
    $stmt_edit = $pdo->prepare($sql_edit);
    $stmt_edit->execute([$id_equip_edit]);
    $equipToEdit = $stmt_edit->fetch(PDO::FETCH_ASSOC);

    if ($equipToEdit) {
        $operacao_form = 'update';
        $form_title = 'Editar Equipamento: ' . htmlspecialchars($equipToEdit['nome_equipa']);
    }
}


$sql = "SELECT 
            Oc.*, 
            User.nome_usuario, 
            Sala.nome_sala, 
            Equip.nome_equipa, 
            Funcao.nome_funcao
        FROM $ocorrencias AS Oc
        LEFT JOIN $usuarios AS User ON Oc.usuarios_id_usuario = User.id_usuario
        LEFT JOIN $funcao AS Funcao ON User.funcao_id = Funcao.id_funcao
        LEFT JOIN $sala AS Sala ON Oc.sala_id = Sala.id_sala
        LEFT JOIN $equipamentos AS Equip ON Oc.equipamentos_id_equip = Equip.id_equip
        ORDER BY 
            CASE Oc.status_ocorrencia 
                WHEN 'Aberto' THEN 1 
                WHEN 'Ativo' THEN 2
                WHEN 'Em Andamento' THEN 3
                ELSE 4 
            END, 
            Oc.data_abertura DESC"; 

$stmt = $pdo->query($sql);
$chamados_ordenados = $stmt->fetchALL(PDO::FETCH_ASSOC); 
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../css/grid.css" />
    <link rel="stylesheet" href="../css/header.css" />
    <link rel="stylesheet" href="../css/aside.css" />
    <link rel="stylesheet" href="../css/stats_card.css" />
    <link rel="stylesheet" href="../css/form_card.css" />
    <link rel="stylesheet" href="../css/list_card.css" />
    <script src="../js/form.js"></script>
    <title>KEL-Keys & Equipaments Logger</title>
    <link rel="icon" type="image/png" href="../images/logoWebIcon.png" />
    
  </head>

  <body>
    <header class="header">
      <section>
        <div class="logo">
          <img
            src="../images/K.E.Lheader.png"
            alt="logo"
            class="logo_etec_header"
          />
        </div>
        <div class="title">
          <h1>KEL-Keys & Equipaments Logger</h1>
          <p>ETEC João Gomes de Araújo</p>
        </div>
         <div class="nav">
            <a href="../php/logout.php" title="Sair do Sistema">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
            </a>
            <img class="img-user" src="../images/manutencao.png" alt="user" />
        </div>
      </section>
    </header>
    <div class="layout">
      <aside>
        <a href="#" class="noti_box">
          <i class="fa-solid fa-bell"></i>
          <span style="font-size: 1.5rem; font-weight: bold">Notificações</span>
        </a>
        <nav>
          <ul>
            <li>
              <a href="#"
                ><i class="fa-solid fa-key"></i
                ><span>Emprestimo sala 4</span></a
              >
            </li>
            <li>
              <a href="#"
                ><i class="fa-solid fa-file-lines"></i
                ><span>Relatório do seu Chamado #358</span></a
              >
            </li>
          </ul>
        </nav>
      </aside>
      <main>
        <h2 class="h2-main">Ola, <?php echo htmlspecialchars($nome_usuario_logado); ?></h2>
        <p class="p-main">
          Bem-vindo ao sistema de cadastro e agendamentos da ETEC João Gomes de
          Araújo
        </p>
        
        <?php if ($mensagem_sucesso): ?>
            <div class="alert alert-success">
                <?php echo $mensagem_sucesso; ?>
            </div>
        <?php endif; ?>

        <?php if ($mensagem_erro): ?>
            <div class="alert alert-error">
                <?php echo $mensagem_erro; ?>
            </div>
        <?php endif; ?>
        
        <div class="manutencao_grid">
          
          <div class="box_1">
            <div class="key-quipament-to-loan">
              <div class="key-layout">
                <div class="key-nav-layout">
                  <h3 class="key-to-loan-title">Todos os Chamados (Ocorrências)</h3>
                </div>
                <div class="key-layout-table">
                  <div class="key-content-table">
                    <table class="key-table-layout">
                      <thead class="key-thead">
                        <tr class="tr-key">
                          <th class="th-key-responsible">Sala</th>
                          <th class="th-key-data">Equip.</th>
                          <th class="th-key-hour">Requisitante</th>
                          <th class="th-key-status">Desc.</th>
                          <th class="th-key-status">Status</th>
                          <th class="th-key-status">Data Ab.</th>
                          <th class="th-key-status">Ações</th> 
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($chamados_ordenados as $chamado): 
                           
                            $status_class = '';
                            if (in_array($chamado['status_ocorrencia'], ['Aberto', 'Ativo', 'Em Andamento'])) {
                                $status_class = 'active-call-row'; 
                            }
                        ?>
                        <tr class="tr-key <?php echo $status_class; ?>">
                          <td class="th-key-responsible" title="<?php echo htmlspecialchars($chamado['nome_sala'] ?? 'N/A'); ?>">
                            <?php echo limitar_texto(htmlspecialchars($chamado['nome_sala'] ?? 'N/A'), 10); ?>
                          </td>
                          <td class="th-key-data" title="<?php echo htmlspecialchars($chamado['nome_equipa'] ?? 'Geral'); ?>">
                            <?php echo limitar_texto(htmlspecialchars($chamado['nome_equipa'] ?? 'Geral'), 10); ?>
                          </td>
                          <td class="th-key-hour" title="<?php echo htmlspecialchars($chamado['nome_usuario'] ?? 'N/A'); ?>">
                            <?php echo limitar_texto(htmlspecialchars($chamado['nome_usuario'] ?? 'N/A'), 12); ?>
                          </td>
                          <td class="th-key-status" title="<?php echo htmlspecialchars($chamado['desc_ocorrencia'] ?? 'N/A'); ?>">
                            <?php echo limitar_texto(htmlspecialchars($chamado['desc_ocorrencia'] ?? 'N/A'), 15); ?>
                          </td>
                          <td class="th-key-status"><?php echo htmlspecialchars($chamado['status_ocorrencia'] ?? 'N/A'); ?></td>
                          <td class="th-key-status"><?php echo htmlspecialchars($chamado['data_abertura'] ?? 'N/A'); ?></td>
                          
                          <td class="th-key-status" style="display:flex; gap: 5px; flex-wrap: wrap;">
                            
                            <?php $status = $chamado['status_ocorrencia']; ?>
                            
                            <?php if ($status === 'Aberto'): ?>
                                <form action="../php/tratarChamadoKel.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="id_ocorrencia" value="<?php echo $chamado['id_ocorrencia']; ?>">
                                    <input type="hidden" name="novo_status" value="Em Andamento">
                                    <button type="submit" 
                                            style="background: #ffc107; color: black; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 0.8rem; font-weight: bold;" 
                                            title="Marcar como Em Andamento"
                                            onclick="return confirm('Mudar chamado #<?php echo $chamado['id_ocorrencia']; ?> para Em Andamento?');">
                                        Andamento
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                            <?php if ($status === 'Em Andamento'): ?>
                                <form action="../php/tratarChamadoKel.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="id_ocorrencia" value="<?php echo $chamado['id_ocorrencia']; ?>">
                                    <input type="hidden" name="novo_status" value="Resolvido">
                                    <button type="submit" 
                                            style="background: #28a745; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 0.8rem; font-weight: bold;" 
                                            title="Finalizar Chamado"
                                            onclick="return confirm('Confirmar a resolução do chamado #<?php echo $chamado['id_ocorrencia']; ?>?');">
                                        Resolver
                                    </button>
                                </form>
                            <?php endif; ?>

                            <?php if ($status === 'Resolvido'): ?>
                                <form action="../php/tratarChamadoKel.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="id_ocorrencia" value="<?php echo $chamado['id_ocorrencia']; ?>">
                                    <input type="hidden" name="novo_status" value="Aberto">
                                    <button type="submit" 
                                            style="background: #dc3545; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 0.8rem; font-weight: bold;" 
                                            title="Reabrir Chamado"
                                            onclick="return confirm('Reabrir o chamado #<?php echo $chamado['id_ocorrencia']; ?>?');">
                                        Reabrir
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                          </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="box_2">
            <div class="key-quipament-to-loan">
              <div class="key-layout">
                <div class="key-nav-layout">
                  <h3 class="key-to-loan-title">Equipamentos Cadastrados</h3>
                </div>
                <div class="key-layout-table">
                  <div class="key-content-table">
                    <table class="key-table-layout">
                      <thead class="key-thead">
                        <tr class="tr-key">
                          <th class="th-key-responsible" style="width: 25%;">Nome</th>
                          <th class="th-key-data" style="width: 25%;">Ident.</th>
                          <th class="th-key-hour" style="width: 25%;">Descrição</th>
                          <th class="th-key-status" style="width: 25%;">Ações</th> 
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($equipamentos_list as $equip): 
                           
                            $sala_nome = 'N/A';
                            foreach ($salas_list as $sala_item) {
                                if ($sala_item['id_sala'] == $equip['salas_id_sala']) {
                                    $sala_nome = $sala_item['nome_sala'];
                                    break;
                                }
                            }
                        ?>
                        <tr class="tr-key">
                           <td class="th-key-responsible" title="<?php echo htmlspecialchars($equip['nome_equipa'] ?? 'N/A'); ?>">
                               <?php echo limitar_texto(htmlspecialchars($equip['nome_equipa'] ?? 'N/A'), 15); ?>
                           </td>
                           <td class="th-key-data" title="<?php echo htmlspecialchars($equip['identificacao_equipa'] ?? 'N/A'); ?>">
                               <?php echo limitar_texto(htmlspecialchars($equip['identificacao_equipa'] ?? 'N/A'), 15); ?>
                           </td>
                           <td class="th-key-hour" title="<?php echo htmlspecialchars($equip['desc_equip'] ?? 'N/A'); ?>">
                               <?php echo limitar_texto(htmlspecialchars($equip['desc_equip'] ?? 'N/A'), 15); ?>
                           </td>
                           <td class="td-key-status">
                                <a href="manutencao_dashboard.php?id_equip=<?php echo $equip['id_equip']; ?>" title="Editar Equipamento">
                                    <i class="fa-solid fa-pen-to-square" style="color: #ffc107;"></i>
                                </a>
                                <a href="../php/excluirKel.php?id_equip=<?php echo $equip['id_equip']; ?>&origem_dashboard=manutencao_dashboard.php" title="Excluir" onclick="return confirm('Excluir Equipamento ID <?php echo $equip['id_equip']; ?>?');">
                                    <i class="fa-solid fa-trash-can" style="color: #dc3545;"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="form">
            <div class="key-nav-layout form-header-align"> 
                <h3 class="key-to-loan-title">
                  <?php echo $form_title; ?>
                </h3>
                
                <?php if ($operacao_form === 'update'): ?>
                    <a href="manutencao_dashboard.php" title="Novo Cadastro" 
                       class="new-cadastro-link"
                       style="font-weight: bold;">
                       Novo Cadastro
                    </a>
                <?php endif; ?>
            </div>
            
             <div class="form-layout">
             
              <form action="../php/salvarKel.php" method="POST" id="loan-key-form">
               <input type="hidden" name="origem_dashboard" value="manutencao_dashboard.php">
               <input type="hidden" name="contexto" value="manutencao_equipamento">
               <input type="hidden" name="operacao" value="<?php echo $operacao_form; ?>">
               <input type="hidden" name="id_equip" value="<?php echo htmlspecialchars($equipToEdit['id_equip'] ?? ''); ?>">
                
                <div id="loan-equipament-content" class="form-inputs">
                  <div class="labels">
                    <br />
                    <label for="responsible-equip-id" class="responsible-label"
                      >Nome do Equipamento:</label
                    ><br />
                    <input
                      type="text"
                      name="nome_equipa" id="responsible-equip-id"
                      class="name-responsible"
                      placeholder="Digite o nome/identificação do equipamento"
                      required
                      value="<?php echo htmlspecialchars($equipToEdit['nome_equipa'] ?? ''); ?>"
                    /><br /><br />
                    
                    <label for="id_sala_select_equip" class="responsible-label">Sala:</label>
                    <select name="salas_id_sala" id="id_sala_select_equip" class="select" required>
                      <option value="" selected disabled > Selecione a Sala</option> 
                      <?php 
                      $selected_id = $equipToEdit['salas_id_sala'] ?? null;
                      foreach ($salas_list as $sala_item): ?>
                          <option 
                            value="<?php echo htmlspecialchars($sala_item['id_sala']); ?>"
                            <?php if ($sala_item['id_sala'] == $selected_id) echo 'selected'; ?>
                          >
                              <?php echo htmlspecialchars($sala_item['nome_sala']); ?>
                          </option>
                      <?php endforeach; ?>
                    </select>
                    <br /><br />
                    
                    <label for="input-equip-num" class="equipament-label"
                      >Identificação (Nº Patrimônio, Serial):</label
                    ><br />
                    <input
                      type="text"
                      name="identificacao_equipa" id="input-equip-num"
                      class="name-key"
                      placeholder="Ex: Numero serial, Numero de patrimonio, etc. "
                      required
                      value="<?php echo htmlspecialchars($equipToEdit['identificacao_equipa'] ?? ''); ?>"
                    /><br /><br />
                    
                    <label for="input-equip-desc" class="equipament-label"
                      >Descrição do Equipamento:</label
                    ><br />
                    <input
                      type="text"
                      name="desc_equip" id="input-equip-desc"
                      class="name-key"
                      placeholder="Digite a descrição do equipamento"
                      value="<?php echo htmlspecialchars($equipToEdit['desc_equip'] ?? ''); ?>"
                    /><br /><br />
                  </div>
                    <div class="btns-to-loan-equipament">
                      <button type="submit" class="to-loan">
                         <?php echo $operacao_form === 'insert' ? 'Cadastrar Equipamento' : 'Salvar Edição'; ?>
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          
        </div>
      </main>
    </div>
  </body>
  <script src="../js/form.js"></script>
</html>