<?php

session_start();

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_usuario'] === null) {
    header("Location: ../login.php"); 
    exit();
}

include '../php/conexaoKel.php'; 


function buscarTodos($pdo, $tabela) {
    $sql = "SELECT * FROM $tabela";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


function buscarUsuariosComFuncao($pdo) {
    $sql = "SELECT u.*, f.nome_funcao 
            FROM Usuarios u
            JOIN Funcao f ON u.funcao_id = f.id_funcao";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function buscarNome($pdo, $tabela, $campoId, $valor, $campoNome) {
    if (!$valor) return 'N/A';
    $sql = "SELECT $campoNome FROM $tabela WHERE $campoId = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$valor]);
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
  
    return $resultado ? htmlspecialchars($resultado[$campoNome]) : 'Não Encontrado';
}


function limitar_texto($texto, $limite) {
    if (!$texto) return 'N/A';
    $texto = (string) $texto;
    if (strlen($texto) > $limite) {
     
        return mb_substr($texto, 0, $limite, 'UTF-8') . '...';
    }
    return $texto;
}

$userToEdit = null;
$operacao_form = 'insert';
$form_title = 'Cadastrar Novo Usuário';

$id_usuario_edit = $_GET['id_usuario'] ?? null;

if ($id_usuario_edit) {
   
    $sql_edit = "SELECT * FROM Usuarios WHERE id_usuario = ?";
    $stmt_edit = $pdo->prepare($sql_edit);
    $stmt_edit->execute([$id_usuario_edit]);
    $userToEdit = $stmt_edit->fetch(PDO::FETCH_ASSOC);

    if ($userToEdit) {
        $operacao_form = 'update';
        $form_title = 'Editar Usuário: ' . htmlspecialchars($userToEdit['nome_usuario']);
    }
}

$salas = buscarTodos($pdo, 'Sala');
$usuarios = buscarUsuariosComFuncao($pdo); 
$ocorrencias = buscarTodos($pdo, 'Ocorrencias');
$funcoes = buscarTodos($pdo, 'Funcao'); 


$nome_usuario_logado = $_SESSION['nome_usuario'] ?? 'Usuário';
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../css/grid.css" />
    <link rel="stylesheet" href="../css/header.css" />
    <link rel="stylesheet" href="../css/aside.css" />
    <link rel="stylesheet" href="../css/stats_card.css" />
    <link rel="stylesheet" href="../css/form_card.css" />
    <link rel="stylesheet" href="../css/list_card.css" />
    <script src="../js/form.js"></script>
    <title>KEL-Keys & Equipaments Logger</title>
    <link rel="icon" type="image/png" href="../images/logoWebIcon.png" />
  </head>

  <body>
    <header class="header">
      <section>
        <div class="logo">
          <img
            src="../images/K.E.Lheader.png"
            alt="logo"
            class="logo_etec_header"
          />
        </div>
        <div class="title">
          <h1>KEL-Keys & Equipaments Logger</h1>
          <p>ETEC João Gomes de Araújo</p>
        </div>
        <div class="nav">
            <a href="../php/logout.php" title="Sair do Sistema"> <i class="fa-solid fa-arrow-right-from-bracket"></i>
            </a>
            <img class="img-user" src="../images/gestao.png" alt="user" />
        </div>
      </section>
    </header>
    <div class="layout">
      <aside>
        <a href="#" class="noti_box">
          <i class="fa-solid fa-bell"></i>
          <span style="font-size: 1.5rem; font-weight: bold">Notificações</span>
        </a>
        <nav>
          <ul>
            <li>
              <a href="#"
                ><i class="fa-solid fa-key"></i
                ><span>Emprestimo sala 4</span></a
              >
            </li>
            <li>
              <a href="#"
                ><i class="fa-solid fa-file-lines"></i
                ><span>Relatório do seu Chamado #358</span></a
              >
            </li>
          </ul>
        </nav>
      </aside>
      <main>
        <h2 class="h2-main">Ola, <?php echo htmlspecialchars($nome_usuario_logado); ?></h2>
        <p class="p-main">
          Bem-vindo ao sistema de cadastro e agendamentos da ETEC João Gomes de
          Araújo
        </p>
        <div class="gestao_grid">
          <div class="box_1">
            <div class="key-quipament-to-loan">
                <div class="key-layout">
                    <div class="key-nav-layout">
                        <h3 class="key-to-loan-title">Chaves/Salas</h3>
                    </div>
                    <div class="key-layout-table">
                        <div class="key-content-table">
                            <table class="key-table-layout" style="table-layout: fixed; width: 99%;">
                                <thead class="key-thead">
                                    <tr class="tr-key">
                                        <th class="th-key-responsible" style="width: 33%;">Sala</th>
                                        <th class="th-key-data" style="width: 33%;">Ident. Chave</th>
                                        <th class="th-key-status" style="width: 33%;">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($salas as $sala): ?>
                                        <tr class="tr-key">
                                            <td class="td-key-responsible" style="padding-left: 10px;"
                                                title="<?php echo htmlspecialchars($sala['nome_sala'] ?? ''); ?>">
                                                <?php echo limitar_texto(htmlspecialchars($sala['nome_sala'] ?? ''), 15); ?>
                                            </td>
                                            <td class="td-key-data" style="padding-left: 70px;"
                                                title="<?php echo htmlspecialchars($sala['identificacao_chave'] ?? ''); ?>">
                                                <?php echo limitar_texto(htmlspecialchars($sala['identificacao_chave'] ?? ''), 10); ?>
                                            </td>
                                            <td class="td-key-status"
                                                title="<?php echo htmlspecialchars($sala['status_sala'] ?? ''); ?>">
                                                <?php echo limitar_texto(htmlspecialchars($sala['status_sala'] ?? ''), 13); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          
          <div class="box_2">
            <div class="key-quipament-to-loan">
              <div class="key-layout">
                <div class="key-nav-layout">
                  <h3 class="key-to-loan-title">Usuarios</h3>
                  </a>
                </div>
                <div class="key-layout-table">
                  <div class="key-content-table">
                    <table class="key-table-layout">
                      <thead class="key-thead">
                        <tr class="tr-key">
                          <th class="th-key" style="width: 20%;">Nome</th>
                          <th class="th-key-responsible" style="width: 35%;">Email</th>
                          <th class="th-key-data" style="width: 25%;">Permissão</th>
                          <th class="th-key-hour" style="width: 20%;">Açoes</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach ($usuarios as $usuario): ?>
                        <tr class="tr-key">
                            <td class="td-key" title="<?php echo htmlspecialchars($usuario['nome_usuario'] ?? 'N/A'); ?>">
                                <?php echo limitar_texto(htmlspecialchars($usuario['nome_usuario'] ?? 'N/A'), 15); ?>
                            </td>
                            <td class="td-key-responsible" title="<?php echo htmlspecialchars($usuario['email'] ?? 'N/A'); ?>">
                                <?php echo limitar_texto(htmlspecialchars($usuario['email'] ?? 'N/A'), 15); ?>
                            </td>
                            <td class="td-key-data" title="<?php echo htmlspecialchars($usuario['nome_funcao'] ?? 'N/A'); ?>">
                                <?php echo limitar_texto(htmlspecialchars($usuario['nome_funcao'] ?? 'N/A'), 15); ?>
                            </td>
                           <td class="td-key-hour">
                                <a href="gestao_dashboard.php?id_usuario=<?php echo $usuario['id_usuario']; ?>" title="Editar Usuário">
                                    <i class="fa-solid fa-pen-to-square" style="color: #ffc107;"></i>
                                </a>
                                <a href="../php/excluirKel.php?id_usuario=<?php echo $usuario['id_usuario']; ?>&origem_dashboard=gestao_dashboard.php" title="Excluir" onclick="return confirm('Excluir Usuário ID <?php echo $usuario['id_usuario']; ?>?');">
                                    <i class="fa-solid fa-trash-can" style="color: #dc3545;"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="box_3">
            <div class="key-quipament-to-loan">
              <div class="key-layout">
                <div class="key-nav-layout">
                  <h3 class="key-to-loan-title">Chamados (Ocorrências)</h3>
                </div>
                <div class="key-layout-table">
                  <div class="key-content-table">
                    <table class="key-table-layout">
                      <thead class="key-thead">
                        <tr class="tr-key">
                          <th class="th-key-responsible">Sala</th>
                          <th class="th-key-data">Equip.</th>
                          <th class="th-key-hour">Requisitante</th>
                          <th class="th-key-status">Desc.</th>
                          <th class="th-key-status">Data Ab.</th>
                          <th class="th-key-status">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach ($ocorrencias as $ocorrencia): 
                          
                            $nome_sala = buscarNome($pdo, 'Sala', 'id_sala', $ocorrencia['sala_id'], 'nome_sala');
                            $nome_equipa = buscarNome($pdo, 'Equipamentos', 'id_equip', $ocorrencia['equipamentos_id_equip'], 'nome_equipa');
                            $nome_usuario = buscarNome($pdo, 'Usuarios', 'id_usuario', $ocorrencia['usuarios_id_usuario'], 'nome_usuario');
                            $desc_ocorrencia = htmlspecialchars($ocorrencia['desc_ocorrencia'] ?? '');
                            $data_abertura = htmlspecialchars($ocorrencia['data_abertura'] ?? '');
                            $status_ocorrencia = htmlspecialchars($ocorrencia['status_ocorrencia'] ?? '');
                        ?>
                        <tr class="tr-key">
                            <td class="td-key-responsible" title="<?php echo $nome_sala; ?>"><?php echo $nome_sala; ?></td>
                            <td class="td-key-data" title="<?php echo $nome_equipa; ?>"><?php echo $nome_equipa; ?></td>
                            <td class="td-key-hour" title="<?php echo $nome_usuario; ?>"><?php echo $nome_usuario; ?></td>
                            <td class="td-key-status" title="<?php echo $desc_ocorrencia; ?>"><?php echo limitar_texto($desc_ocorrencia, 15); ?></td>
                            <td class="td-key-status" title="<?php echo $data_abertura; ?>"><?php echo $data_abertura; ?></td>
                            <td class="td-key-status" title="<?php echo $status_ocorrencia; ?>"><?php echo $status_ocorrencia; ?></td>
                            
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="form">
            <div class="key-nav-layout form-header-align"> 
                <h3 class="key-to-loan-title">
                  <?php echo $form_title; ?>
                </h3>
                
                <?php if ($operacao_form === 'update'): ?>
                    <a href="gestao_dashboard.php" title="Novo Cadastro" 
                       class="new-cadastro-link"
                       style="font-weight: bold;">
                       Novo Cadastro
                    </a>
                <?php endif; ?>
            </div>
            
            <div class="form-layout">
              <form action="../php/salvarKel.php" method="POST" id="loan-key-form">
                <input type="hidden" name="origem_dashboard" value="gestao_dashboard.php">
                
                <input type="hidden" name="contexto" value="gestao_usuario">
                <input type="hidden" name="operacao" value="<?php echo $operacao_form; ?>">
                <input type="hidden" name="id_usuario" value="<?php echo htmlspecialchars($userToEdit['id_usuario'] ?? ''); ?>">
                
                <div id="loan-key-content" class="form-inputs">
                  <div class="labels">
                    <br />
                    <label for="responsible-key-nome" class="responsible-label"
                      >Nome:</label
                    ><br />
                    <input
                      type="text"
                      name="nome_usuario" id="responsible-key-nome"
                      class="name-responsible"
                      placeholder="Digite o nome do usuario"
                      required
                      value="<?php echo htmlspecialchars($userToEdit['nome_usuario'] ?? ''); ?>"
                    /><br /><br />
                    <label for="input-key-email" class="key-label">Email:</label
                    ><br />
                    <input
                      type="email"
                      name="email" id="input-key-email"
                      class="name-key"
                      placeholder="Digite o email do usuario"
                      required
                      value="<?php echo htmlspecialchars($userToEdit['email'] ?? ''); ?>"
                    /><br /><br />
                      <label for="input-key-senha" class="key-label">Senha: 
                        <?php if ($operacao_form === 'update') echo "(Deixe vazio para manter a senha atual)"; ?>
                      </label
                    ><br />
                    <input
                      type="password"
                      name="senha" id="input-key-senha"
                      class="name-key"
                      placeholder="Digite a senha"
                      <?php if ($operacao_form === 'insert') echo 'required'; ?>
                      /><br /><br />
                      <label for="id_chave_select" class="responsible-label">Permissão:</label>
                    <select name="funcao_id" id="id_chave_select" class="select" required> <option value="" selected disabled > Selecione a Permissão</option> 
                      <?php 
                      $selected_id = $userToEdit['funcao_id'] ?? null;
                      foreach ($funcoes as $funcao): ?>
                      <option 
                        value="<?php echo htmlspecialchars($funcao['id_funcao']); ?>"
                        <?php if ($funcao['id_funcao'] == $selected_id) echo 'selected'; ?>
                      >
                          <?php echo htmlspecialchars($funcao['nome_funcao']); ?>
                      </option>
                      <?php endforeach; ?>
                   </select>
                  </div>
                    <div class="btns-to-loan-key">
                      <button type="submit" class="to-loan">
                          <?php echo $operacao_form === 'insert' ? 'Cadastrar Usuário' : 'Salvar Edição'; ?>
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
  </body>
  <script src="../js/form.js"></script>
</html>