<?php

session_start();


if (!isset($_SESSION['id_usuario']) || $_SESSION['id_usuario'] === null) {
    header("Location: ../login.php"); 
    exit();
}


include '../php/conexaoKel.php'; 


function buscarTodos($pdo, $tabela) {
    $sql = "SELECT * FROM $tabela";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


function buscarEmprestimosComNomes($pdo) {
    $sql = "SELECT 
                e.*, 
                s.nome_sala, 
                s.identificacao_chave, 
                u.nome_usuario 
            FROM Emprestimo e
            LEFT JOIN Sala s ON e.salas_id_sala = s.id_sala
            LEFT JOIN Usuarios u ON e.usuario_id_usuario = u.id_usuario
            ORDER BY 
                e.data_hora_devolucao IS NULL DESC,
                e.id_emprestimo DESC";             
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


function limitar_texto($texto, $limite) {
    if (!$texto) return 'N/A'; 

    $texto = (string) $texto;
    if (strlen($texto) > $limite) {
        return mb_substr($texto, 0, $limite, 'UTF-8') . '...';
    }
    return $texto;
}




$salaToEdit = null;
$operacao_sala_form = 'insert';
$form_title_sala = 'Cadastrar Nova Chave';
$editando = false; 

$id_sala_edit = $_GET['id_sala'] ?? null;

if ($id_sala_edit) {

    $sql_edit = "SELECT * FROM Sala WHERE id_sala = ?";
    $stmt_edit = $pdo->prepare($sql_edit);
    $stmt_edit->execute([$id_sala_edit]);
    $salaToEdit = $stmt_edit->fetch(PDO::FETCH_ASSOC);

    if ($salaToEdit) {
        $operacao_sala_form = 'update';

        $form_title_sala = 'Editando Chave: ' . htmlspecialchars($salaToEdit['identificacao_chave'] ?? '');
        $editando = true;
    }
}



$salas = buscarTodos($pdo, 'Sala');
$usuarios = buscarTodos($pdo, 'Usuarios'); 
$emprestimos = buscarEmprestimosComNomes($pdo); 


$nome_usuario_logado = $_SESSION['nome_usuario'] ?? 'Usuário';
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../css/grid.css" />
    <link rel="stylesheet" href="../css/header.css" />
    <link rel="stylesheet" href="../css/aside.css" />
    <link rel="stylesheet" href="../css/stats_card.css" />
    <link rel="stylesheet" href="../css/form_card.css" />
    <link rel="stylesheet" href="../css/list_card.css" />
    <style>
    
      .hidden-content {
          display: none !important; 
      }
    </style>
    <script src="../js/form.js"></script>
    <title>KEL-Keys & Equipaments Logger</title>
    <link rel="icon" type="image/png" href="../images/logoWebIcon.png" />
  </head>

  <body>
    <header class="header">
      <section>
        <div class="logo">
          <img
            src="../images/K.E.Lheader.png"
            alt="logo"
            class="logo_etec_header"
          />
        </div>
        <div class="title">
          <h1>KEL-Keys & Equipaments Logger</h1>
          <p>ETEC João Gomes de Araújo</p>
        </div>
         <div class="nav">
            <a href="../php/logout.php" title="Sair do Sistema">
              <i class="fa-solid fa-arrow-right-from-bracket"></i>
            </a>
            <img class="img-user" src="../images/portaria.png" alt="user" />
        </div>
      </section>
    </header>
    <div class="layout">
      <aside>
        <a href="#" class="noti_box">
          <i class="fa-solid fa-bell"></i>
          <span style="font-size: 1.5rem; font-weight: bold">Notificações</span>
        </a>
        <nav>
          <ul>
            <li>
              <a href="#"
                ><i class="fa-solid fa-key"></i
                ><span>Emprestimo sala 4</span></a
              >
            </li>
            <li>
              <a href="#"
                ><i class="fa-solid fa-file-lines"></i
                ><span>Relatório do seu Chamado #358</span></a
              >
            </li>
          </ul>
        </nav>
      </aside>
      <main>
        <h2 class="h2-main">Ola, <?php echo htmlspecialchars($nome_usuario_logado); ?></h2>
        <p class="p-main">
          Bem-vindo ao sistema de cadastro e agendamentos da ETEC João Gomes de
          Araújo
        </p>
        <div class="portaria_grid">
          <div class="box_1">
            <div class="key-quipament-to-loan">
              <div class="key-layout">
                <div class="key-nav-layout">
                  <h3 class="key-to-loan-title">Chaves/Salas</h3>
                </div>
                <div class="key-layout-table">
                  <div class="key-content-table">
                    <table class="key-table-layout">
                      <thead class="key-thead">
                        <tr class="tr-key">
                          <th class="th-key">Ident. chave</th>
                          <th class="th-key-responsible">Sala</th>
                          <th class="th-key-data">Desc.</th>
                          <th class="th-key-status">Status</th>
                          <th class="th-key-status">Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach ($salas as $sala): 
                            $identificacao_chave = htmlspecialchars($sala['identificacao_chave'] ?? '');
                            $nome_sala = htmlspecialchars($sala['nome_sala'] ?? '');
                            $desc_sala = htmlspecialchars($sala['desc_sala'] ?? '');
                            $status_sala = htmlspecialchars($sala['status_sala'] ?? '');
                        ?>
                        <tr class="tr-key">
                            <td class="td-key" title="<?php echo $identificacao_chave; ?>">
                                <?php echo limitar_texto($identificacao_chave, 10); ?>
                            </td>
                            <td class="td-key-responsible" title="<?php echo $nome_sala; ?>">
                                <?php echo limitar_texto($nome_sala, 15); ?>
                            </td>
                            <td class="td-key-data" title="<?php echo $desc_sala; ?>">
                                <?php echo limitar_texto($desc_sala, 20); ?>
                            </td>
                            <td class="td-key-status" title="<?php echo $status_sala; ?>">
                                <?php echo limitar_texto($status_sala, 13); ?>
                            </td>
                            <td class="td-key-status">
                                <a href="portaria_dashboard.php?id_sala=<?php echo $sala['id_sala']; ?>" title="Editar Sala">
                                    <i class="fa-solid fa-pen-to-square" style="color: #ffc107;"></i>
                                </a>
                                <a href="../php/excluirKel.php?id_sala=<?php echo $sala['id_sala']; ?>&origem_dashboard=portaria_dashboard.php" title="Excluir" onclick="return confirm('Excluir Sala ID <?php echo $sala['id_sala']; ?>?');">
                                    <i class="fa-solid fa-trash-can" style="color: #dc3545;"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="box_2">
            <div class="key-quipament-to-loan">
              <div class="key-layout">
                <div class="key-nav-layout">
                  <h3 class="key-to-loan-title">Histórico de Empréstimos (Devolução)</h3>
                </div>
                <div class="key-layout-table">
                  <div class="key-content-table">
                    <table class="key-table-layout">
                      <thead class="key-thead">
                        <tr class="tr-key">
                          <th class="th-key">Sala</th>
                          <th class="th-key-responsible">Respons.</th>
                          <th class="th-key-data">Retirada</th>
                          <th class="th-key-hour">Devolução</th> 
                          <th class="th-key-status">Status/Ações</th>
                        </tr>
                      </thead>
                       <tbody>
                        <?php foreach ($emprestimos as $emprestimo): 
                            $nome_sala = htmlspecialchars($emprestimo['nome_sala'] ?? 'N/A');
                            $nome_usuario = htmlspecialchars($emprestimo['nome_usuario'] ?? 'N/A');
                            
                            $retirada_full = htmlspecialchars($emprestimo['data_hora_retirada'] ?? 'N/A N/A');
                            $retirada = explode(" ", $emprestimo['data_hora_retirada'] ?? 'N/A N/A');
                            
                            $devolucao_full = empty($emprestimo['data_hora_devolucao']) ? 'Em Aberto' : htmlspecialchars($emprestimo['data_hora_devolucao']);
                            $devolucao = explode(" ", $emprestimo['data_hora_devolucao'] ?? 'N/A N/A');
                            
                            $status_emprestimo = empty($emprestimo['data_hora_devolucao']) ? 'Em Aberto' : 'Devolvido';
                        ?>
                        <tr class="tr-key">
                            <td class="td-key" title="<?php echo $nome_sala; ?>"><?php echo limitar_texto($nome_sala, 15); ?></td>
                            <td class="td-key-responsible" title="<?php echo $nome_usuario; ?>"><?php echo limitar_texto($nome_usuario, 15); ?></td>
                            <td class="td-key-data" title="<?php echo $retirada_full; ?>">
                                <?php echo limitar_texto($retirada[0], 10) . ' ' . limitar_texto($retirada[1], 8); ?>
                            </td>
                            
                            <td class="td-key-hour" title="<?php echo $devolucao_full; ?>">
                              <?php echo empty($emprestimo['data_hora_devolucao']) ? 'Em Aberto' : limitar_texto($devolucao[0], 10) . ' ' . limitar_texto($devolucao[1], 8); ?>
                            </td>
                            
                            <td class="td-key-status">
                                <?php if ($status_emprestimo === 'Em Aberto'): ?>
                                    <form action="../php/salvarKel.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="contexto" value="portaria_devolucao">
                                        <input type="hidden" name="origem_dashboard" value="portaria_dashboard.php">
                                        <input type="hidden" name="id_emprestimo" value="<?php echo $emprestimo['id_emprestimo']; ?>">
                                        <button type="submit" 
                                                style="background: #dc3545; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 0.8rem;" 
                                                title="Registrar Devolução" 
                                                onclick="return confirm('Confirmar devolução da chave da sala <?php echo $emprestimo['nome_sala']; ?>?');">
                                            Devolver
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <?php echo $status_emprestimo; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="form">
            <div class="form-nav">
              
               <?php if ($editando): ?>
                <div class="key-nav-layout form-header-align"> 
                    <h3 class="key-to-loan-title">
                        <?php echo htmlspecialchars($form_title_sala ?? 'Editar Chave'); ?>
                    </h3>
                    <a href="portaria_dashboard.php" 
                       title="Novo Cadastro de Chave"
                       class="new-cadastro-link" 
                       style="font-weight: bold;">
                       Novo Cadastro
                    </a>
                </div>
              <?php else: ?>
                <nav class="nav-form">
                  <button id="key" class="land-key activi">
                    Emprestar Chave
                  </button>
                  <button id="equipament" class="land-equipament">
                    Cadastrar Chave
                  </button>
                </nav>
              <?php endif; ?>

            </div>
            <div class="form-layout">
              <form 
                  action="../php/salvarKel.php" 
                  method="POST" 
                  id="loan-key-form" 
                  class="<?php echo $editando ? 'hidden-content' : ''; ?>"
              >
                <input type="hidden" name="origem_dashboard" value="portaria_dashboard.php">
                <input type="hidden" name="contexto" value="portaria_emprestimo">
                <div id="loan-key-content" class="form-inputs">
                  <div class="labels">
                    <br />
                    <label for="id_usuario_select" class="responsible-label">Responsável:</label>
                    <select name="usuario_id_usuario" id="id_usuario_select" class="select" required>
                      <option value="" selected disabled > Selecione o usuário</option> 
                      <?php foreach ($usuarios as $usuario): ?>
                      <option 
                        value="<?php echo htmlspecialchars($usuario['id_usuario']); ?>"
                        title="<?php echo htmlspecialchars($usuario['nome_usuario']); ?>"
                      >
                          <?php echo limitar_texto(htmlspecialchars($usuario['nome_usuario']), 20); ?>
                      </option>
                      <?php endforeach; ?>
                   </select>

                    <label for="id_chave_select" class="responsible-label">Chave/Sala (Disponível):</label>
                    <select name="salas_id_sala" id="id_chave_select" class="select" required>
                      <option value="" selected disabled > Selecione a Chave/Sala</option> 
                      <?php foreach ($salas as $sala): 
                         
                            if ($sala['status_sala'] === 'Disponível'):
                                $chave_display = htmlspecialchars($sala['nome_sala']) . ' (' . htmlspecialchars($sala['identificacao_chave']) . ')';
                      ?>
                      <option 
                        value="<?php echo htmlspecialchars($sala['id_sala']); ?>"
                        title="<?php echo $chave_display; ?>"
                      >
                          <?php echo limitar_texto($chave_display, 20); ?>
                      </option>
                      <?php 
                            endif;
                          endforeach; 
                      ?>
                   </select>
                  </div>
                  <div class="status">
                    <div class="btns-to-loan-key">
                      <button type="submit" class="to-loan">Registrar Retirada</button>
                    </div>
                  </div>
                </div>
              </form>

              <form 
                  action="../php/salvarKel.php" 
                  method="POST" 
                  id="loan-equipament-form" 
                  class="<?php echo (!$editando) ? 'hidden-content' : ''; ?>"
              >
             

                 <input type="hidden" name="origem_dashboard" value="portaria_dashboard.php">
                <input type="hidden" name="contexto" value="portaria_cadastro_sala">
                <input type="hidden" name="operacao" value="<?php echo $operacao_sala_form; ?>">
                <input type="hidden" name="id_sala" value="<?php echo htmlspecialchars($salaToEdit['id_sala'] ?? ''); ?>">

                <div id="loan-equipament-content" class="form-inputs">
                  <div class="labels">
                    <br /><br />
                    <label for="nome_sala_input" class="responsible-label"
                      >Nome da Sala:</label
                    ><br />
                    <input
                      type="text"
                      name="nome_sala"
                      id="nome_sala_input"
                      class="name-responsible"
                      placeholder="Ex: Sala 10, Laboratório de Info 1"
                      required
                      value="<?php echo htmlspecialchars($salaToEdit['nome_sala'] ?? ''); ?>"
                    />

                    <label for="identificacao_chave_input" class="responsible-label"
                      >Identificação da Chave:</label
                    ><br />
                    <input
                      type="text"
                      name="identificacao_chave"
                      id="identificacao_chave_input"
                      class="name-responsible"
                      placeholder="Ex: Chave S-10"
                      required
                      value="<?php echo htmlspecialchars($salaToEdit['identificacao_chave'] ?? ''); ?>"
                    />
                    
                    <label for="desc_sala_input" class="equipament-label"
                      >Descrição:</label
                    ><br />
                    <input
                      type="text"
                      name="desc_sala"
                      id="desc_sala_input"
                      class="name-key"
                      placeholder="Descrição breve (Opcional)"
                      value="<?php echo htmlspecialchars($salaToEdit['desc_sala'] ?? ''); ?>"
                    /><br />

                    <?php if ($operacao_sala_form === 'update'): ?>
                    <br>
                    <label for="status_sala_select" class="equipament-label"
                      >Status da Chave/Sala:</label
                    ><br />
                    <select name="status_sala" id="status_sala_select" class="select" required>
                      <?php 
                        $current_status = $salaToEdit['status_sala'] ?? 'Disponível';
                        $options = ['Disponível', 'Emprestado', 'Manutenção'];
                        foreach ($options as $option): 
                      ?>
                      <option value="<?php echo $option; ?>" <?php if ($option == $current_status) echo 'selected'; ?>>
                          <?php echo $option; ?>
                      </option>
                      <?php endforeach; ?>
                    </select>
                    <?php endif; ?>

                  </div>
                    <div class="btns-to-loan-equipament">
                      <button type="submit" class="to-loan">
                          <?php echo $operacao_sala_form === 'insert' ? 'Cadastrar Sala/Chave' : 'Salvar Edição'; ?>
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
  </body>
  <script src="../js/form.js"></script>
</html>