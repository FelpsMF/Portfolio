<?php
session_start();

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_usuario'] === null) {
    header("Location: ../login.php"); 
    exit();
}

include '../php/conexaoKel.php'; 


$id_usuario_logado = $_SESSION['id_usuario'];
$nome_usuario_logado = $_SESSION['nome_usuario'] ?? 'Professor';

function buscarTodos($pdo, $tabela) {
    $sql = "SELECT * FROM $tabela";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function buscarNome($pdo, $tabela, $campoId, $valor, $campoNome) {
    if (!$valor) return 'N/A';
    $sql = "SELECT $campoNome FROM $tabela WHERE $campoId = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$valor]);
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    return $resultado ? htmlspecialchars($resultado[$campoNome]) : 'Não Encontrado';
}

function limitar_texto($texto, $limite) {
    if (!$texto) return 'N/A'; 
    $texto = (string) $texto;
    if (strlen($texto) > $limite) {
        return mb_substr($texto, 0, $limite, 'UTF-8') . '...';
    }
    return $texto;
}


function buscarEmprestimosAtivosUsuario($pdo, $id_usuario) {
    $sql = "SELECT 
                e.*, 
                s.nome_sala, 
                s.identificacao_chave 
            FROM Emprestimo e
            LEFT JOIN Sala s ON e.salas_id_sala = s.id_sala
            WHERE e.usuario_id_usuario = ? AND e.data_hora_devolucao IS NULL
            ORDER BY e.data_hora_retirada DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id_usuario]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


function buscarOcorrenciasUsuario($pdo, $id_usuario) {
    $sql = "SELECT 
                Oc.*, 
                Sala.nome_sala, 
                Equip.nome_equipa 
            FROM Ocorrencias AS Oc
            LEFT JOIN Sala AS Sala ON Oc.sala_id = Sala.id_sala
            LEFT JOIN Equipamentos AS Equip ON Oc.equipamentos_id_equip = Equip.id_equip
            WHERE Oc.usuarios_id_usuario = ?
            ORDER BY 
                CASE Oc.status_ocorrencia 
                    WHEN 'Aberto' THEN 1 
                    WHEN 'Em Andamento' THEN 2
                    ELSE 3 
                END, 
                Oc.data_abertura DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id_usuario]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


$salas = buscarTodos($pdo, 'Sala');
$equipamentos = buscarTodos($pdo, 'Equipamentos');
$meus_emprestimos = buscarEmprestimosAtivosUsuario($pdo, $id_usuario_logado);
$minhas_ocorrencias = buscarOcorrenciasUsuario($pdo, $id_usuario_logado);

?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../css/grid.css" />
    <link rel="stylesheet" href="../css/header.css" />
    <link rel="stylesheet" href="../css/aside.css" />
    <link rel="stylesheet" href="../css/stats_card.css" />
    <link rel="stylesheet" href="../css/form_card.css" />
    <link rel="stylesheet" href="../css/list_card.css" />
    <script src="../js/form.js"></script>
    <title>KEL-Keys & Equipaments Logger</title>
    <link rel="icon" type="image/png" href="../images/logoWebIcon.png" />
    <style>
      .active-call-row {
          background-color: #fff3cd !important; 
          border-left: 5px solid #ffc107;
      }
    </style>
  </head>

  <body>
    <header class="header">
      <section>
        <div class="logo">
          <img
            src="../images/K.E.Lheader.png"
            alt="logo"
            class="logo_etec_header"
          />
        </div>
        <div class="title">
          <h1>KEL-Keys & Equipaments Logger</h1>
          <p>ETEC João Gomes de Araújo</p>
        </div>
        <div class="nav">
            <a href="../php/logout.php" title="Sair do Sistema">
              <i class="fa-solid fa-arrow-right-from-bracket"></i>
            </a>
            <img class="img-user" src="../images/professor.png" alt="user" />
        </div>
      </section>
    </header>
    <div class="layout">
      <aside>
        <a href="#" class="noti_box">
          <i class="fa-solid fa-bell"></i>
          <span style="font-size: 1.5rem; font-weight: bold">Notificações</span>
        </a>
        <nav>
          <ul>
            <li>
              <a href="#"
                ><i class="fa-solid fa-key"></i
                ><span>Emprestimo sala 4</span></a
              >
            </li>
            <li>
              <a href="#"
                ><i class="fa-solid fa-file-lines"></i
                ><span>Relatório do seu Chamado #358</span></a
              >
            </li>
          </ul>
        </nav>
      </aside>
      <main>
        <h2 class="h2-main">Ola, <?php echo htmlspecialchars($nome_usuario_logado); ?></h2>
        <p class="p-main">
          Bem-vindo ao sistema de cadastro e agendamentos da ETEC João Gomes de
          Araújo
        </p>
        <div class="professor_grid">
          <div class="box_1">
            <div class="key-quipament-to-loan">
              <div class="key-layout">
                <div class="key-nav-layout">
                  <h3 class="key-to-loan-title">Meus Empréstimos Ativos</h3>
                </div>
                <div class="key-layout-table">
                  <div class="key-content-table">
                    <table class="key-table-layout">
                      <thead class="key-thead">
                        <tr class="tr-key">
                          <th class="th-key" >Sala</th>
                          <th class="th-key-responsible" >Ident. Chave</th>
                          <th class="th-key-data" >Retirada</th>
                          <th class="th-key-status" >Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach ($meus_emprestimos as $emprestimo): 
                            $nome_sala = htmlspecialchars($emprestimo['nome_sala'] ?? 'N/A');
                            $identificacao_chave = htmlspecialchars($emprestimo['identificacao_chave'] ?? 'N/A');
                            $data_retirada = htmlspecialchars($emprestimo['data_hora_retirada'] ?? 'N/A');
                        ?>
                        <tr class="tr-key">
                            <td class="td-key" title="<?php echo $nome_sala; ?>">
                                <?php echo limitar_texto($nome_sala, 15); ?>
                            </td>
                            <td class="td-key-responsible" title="<?php echo $identificacao_chave; ?>">
                                <?php echo limitar_texto($identificacao_chave, 15); ?>
                            </td>
                            <td class="td-key-data" title="<?php echo $data_retirada; ?>">
                                <?php echo limitar_texto($data_retirada, 20); ?>
                            </td>
                            <td class="td-key-status" title="Em Aberto (Aguardando Devolução na Portaria)">
                                Em Aberto
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="box_2">
            <div class="key-quipament-to-loan">
              <div class="key-layout">
                <div class="key-nav-layout">
                  <h3 class="key-to-loan-title">Meus Chamados (Ocorrências)</h3>
                </div>
                <div class="key-layout-table">
                  <div class="key-content-table">
                    <table class="key-table-layout">
                      <thead class="key-thead">
                        <tr class="tr-key">
                          <th class="th-key-responsible">Sala</th>
                          <th class="th-key-data">Equip.</th>
                          <th class="th-key-hour">Desc.</th>
                          <th class="th-key-status">Data Ab.</th>
                          <th class="th-key-status">Status</th>
                          <th class="th-key-status">Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($minhas_ocorrencias as $ocorrencia):
                            $status_class = '';
                            if (in_array($ocorrencia['status_ocorrencia'], ['Aberto', 'Em Andamento'])) {
                                $status_class = 'active-call-row'; 
                            }
                            
                            $nome_sala = htmlspecialchars($ocorrencia['nome_sala'] ?? 'N/A');
                            $nome_equipa = htmlspecialchars($ocorrencia['nome_equipa'] ?? 'Geral');
                            $desc_ocorrencia = htmlspecialchars($ocorrencia['desc_ocorrencia'] ?? 'N/A');
                            $data_abertura = htmlspecialchars($ocorrencia['data_abertura'] ?? 'N/A');
                            $status_ocorrencia = htmlspecialchars($ocorrencia['status_ocorrencia'] ?? 'N/A');
                        ?>
                        <tr class="tr-key <?php echo $status_class; ?>">
                            <td class="td-key-responsible" title="<?php echo $nome_sala; ?>">
                                <?php echo limitar_texto($nome_sala, 10); ?>
                            </td>
                            <td class="td-key-data" title="<?php echo $nome_equipa; ?>">
                                <?php echo limitar_texto($nome_equipa, 10); ?>
                            </td>
                            <td class="td-key-hour" title="<?php echo $desc_ocorrencia; ?>">
                                <?php echo limitar_texto($desc_ocorrencia, 15); ?>
                            </td>
                            <td class="td-key-status" title="<?php echo $data_abertura; ?>">
                                <?php echo limitar_texto($data_abertura, 10); ?>
                            </td>
                            <td class="td-key-status" title="<?php echo $status_ocorrencia; ?>">
                                <?php echo limitar_texto($status_ocorrencia, 13); ?>
                            </td>
                            <td class="td-key-status">
                                <?php if ($ocorrencia['status_ocorrencia'] === 'Aberto'): ?>
                                    <a href="../php/excluirKel.php?id_ocorrencia=<?php echo $ocorrencia['id_ocorrencia']; ?>&origem_dashboard=professor_dashboard.php" title="Cancelar Chamado" onclick="return confirm('Cancelar este chamado (Ocorrência #<?php echo $ocorrencia['id_ocorrencia']; ?>)?');">
                                        <i class="fa-solid fa-xmark" style="color: #dc3545;"></i>
                                    </a>
                                <?php elseif ($ocorrencia['status_ocorrencia'] === 'Resolvido'): ?>
                                    <span style="color: #28a745; font-weight: bold;">Finalizado</span>
                                <?php else: ?>
                                    <span style="color: #ffc107; font-weight: bold;">Em Andamento</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="form">
            <div class="key-nav-layout form-header-align"> 
                <h3 class="key-to-loan-title">
                  Abrir Chamado (Ocorrência)
                </h3>
            </div>
            <div class="form-layout">
              <form action="../php/salvarKel.php" method="POST" id="loan-key-form">
                <input type="hidden" name="origem_dashboard" value="professor_dashboard.php">
                <input type="hidden" name="contexto" value="professor_ocorrencia">
                <input type="hidden" name="usuarios_id_usuario" value="<?php echo $id_usuario_logado; ?>">
                
                <div id="loan-key-content" class="form-inputs">
                  <div class="labels">
                    <br />
                    
                    <label for="id_sala_select" class="responsible-label">Sala:</label>
                    <select name="sala_id" id="id_sala_select" class="select" required>
                      <option value="" selected disabled > Selecione a Sala Onde Ocorreu</option> 
                      <?php foreach ($salas as $sala): ?>
                      <option 
                        value="<?php echo htmlspecialchars($sala['id_sala']); ?>"
                        title="<?php echo htmlspecialchars($sala['nome_sala']); ?>"
                      >
                          <?php echo limitar_texto(htmlspecialchars($sala['nome_sala']), 25); ?>
                      </option>
                      <?php endforeach; ?>
                   </select><br /><br />
                   
                     <label for="id_equip_select" class="responsible-label">Equipamento (Opcional):</label>
                    <select name="equipamentos_id_equip" id="id_equip_select" class="select">
                       <option value="">Nenhum Equipamento Específico (Geral da Sala)</option>
                      <?php foreach ($equipamentos as $equipamento): 
                        
                          $nome_sala_equip = buscarNome($pdo, 'Sala', 'id_sala', $equipamento['salas_id_sala'], 'nome_sala');
                          $title_text = htmlspecialchars($equipamento['nome_equipa']) . " (Sala: " . $nome_sala_equip . ")";
                      ?>
                          <option 
                            value="<?php echo htmlspecialchars($equipamento['id_equip']); ?>"
                            title="<?php echo $title_text; ?>"
                          >
                              <?php echo limitar_texto(htmlspecialchars($equipamento['nome_equipa']), 25); ?>
                          </option>
                      <?php endforeach; ?>
                   </select><br /><br />

                     <label for="input-key-descricao" class="key-label">Descrição:</label><br />
                    <input
                      type="text"
                      name="desc_ocorrencia"
                      id="input-key-descricao"
                      class="name-key"
                      placeholder="Digite uma descrição clara e objetiva"
                      required
                      /><br /><br />
                  </div>
                    <div class="btns-to-loan-key">
                      <button type="submit" class="to-loan">Realizar Chamado</button>
                    </div>
                  </div>
                </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  </body>
  <script src="../js/form.js"></script>
</html>