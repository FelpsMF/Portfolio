document.addEventListener("DOMContentLoaded", () => {
  const btnEmprestar = document.getElementById("key");
  const btnEquipamento = document.getElementById("equipament");

  const formChave = document.getElementById("loan-key-form");
  const formEquipamento = document.getElementById("loan-equipament-form");

  if (!btnEmprestar || !btnEquipamento || !formChave || !formEquipamento) {
    console.log(
      "Modo de Edição Ativo ou elementos de aba não encontrados. JS de controle de aba ignorado."
    );
    return;
  }




  btnEmprestar.addEventListener("click", () => {

    btnEmprestar.classList.add("activi");
    btnEquipamento.classList.remove("activi");


    formChave.classList.remove("hidden-content");

    formEquipamento.classList.add("hidden-content");
  });


  btnEquipamento.addEventListener("click", () => {

    btnEquipamento.classList.add("activi");
    btnEmprestar.classList.remove("activi");


    formEquipamento.classList.remove("hidden-content");

    formChave.classList.add("hidden-content");
  });
});
