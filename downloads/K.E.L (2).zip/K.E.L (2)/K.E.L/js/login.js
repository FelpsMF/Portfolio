
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("login-form");

  const campoUsuario = document.getElementById("usuario");
  const campoSenha = document.getElementById("senha");

  const botaoLogin = form.querySelector(".login-button");

  if (!form || !campoUsuario || !campoSenha || !botaoLogin) {
    console.error(
      "Erro: Elementos do formulário de login não foram encontrados."
    );
    return;
  }

  form.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      event.preventDefault();

      if (document.activeElement === campoUsuario) {
        campoSenha.focus();
      } else if (document.activeElement === campoSenha) {
        botaoLogin.click();
      }
    }
  });
});

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("login-form");

  const campoUsuario = document.getElementById("usuario");
  const campoSenha = document.getElementById("senha");

  const botaoLogin = form.querySelector(".login-button");

  if (!form || !campoUsuario || !campoSenha || !botaoLogin) {
    console.error(
      "Erro: Elementos do formulário de login não foram encontrados."
    );
    return;
  }

  form.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      event.preventDefault();

      if (document.activeElement === campoUsuario) {
        campoSenha.focus();
      } else if (document.activeElement === campoSenha) {
        botaoLogin.click();
      }
    }
  });
});


function toggleAlertaBalao(event) {
  event.preventDefault();

  var dialog = document.getElementById("dialog-box");
  var link = document.getElementById("forgot-password-link");

  var contRef = link.closest(".login-content");

  if (dialog.style.display !== "none" && dialog.style.visibility !== "hidden") {
    dialog.style.display = "none";
    return;
  }

  var linkRect = link.getBoundingClientRect();
  var contRect = contRef.getBoundingClientRect();

  dialog.style.visibility = "hidden";
  dialog.style.display = "block";

  var topPosition = linkRect.top - contRect.top - dialog.offsetHeight - 10;

  dialog.style.top = topPosition + "px";

  dialog.style.visibility = "visible";
}

function fecharAlertaBalao() {
  document.getElementById("dialog-box").style.display = "none";
}
