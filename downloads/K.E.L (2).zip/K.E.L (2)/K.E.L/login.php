<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login K.E.L - ETEC</title>
    <link rel="icon" type="image/png" href="images/logoWebIcon.png" />
    <link rel="stylesheet" href="css/login.css" />
    <link rel="stylesheet" href="js/login.js" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="login-container">
      <div class="login-header-red">LOGIN</div>
      <div class="login-content">
        <div class="welcome-section">
          <div class="kel-logo">
            <img src="./images/logo.png" alt="Logo K.E.L" />
          </div>
          <div class="welcome-text">
            <h2>Bem-vindo ao <span style="color: #861717">
      K<span style="color: #0002a3">.</span>E<span style="color: #0002a3">.</span>L
   </h2>
            <p>seu sistema de gestão inteligente</p>
          </div>
        </div>
        
       <form id="login-form" action="php/autenticar.php" method="post">
    <div class="form-group">
        <label for="usuario" class="usuario">Nome de Usuário</label>
        <input type="text" id="usuario" name="username" required />
        </div>
    <div class="form-group">
        <label for="senha" class="senha">Senha</label>
        <input type="password" id="senha" name="password" required />
    </div>
    <div class="login-options">
    </div>
    <button type="submit" class="login-button">ENTRAR</button>
    
    <?php 
    if (isset($_GET['error']) && $_GET['error'] == 1) {
        echo '<p style="color: red; margin-top: 10px;">Usuário ou senha inválidos!</p>';
    }
    ?>
</form>
</div>
</div> </div>
  </body>
</html>